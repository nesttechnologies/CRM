﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Charts001
{
    public interface IJsonData {
    }
    public class JsonData
    {

    }
}