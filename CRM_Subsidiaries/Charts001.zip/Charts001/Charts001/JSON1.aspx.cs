﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using FusionCharts.Charts;
using System.Text;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.SqlClient;
using Newtonsoft.Json.Linq;
using System.IO;
using Newtonsoft.Json;

namespace Charts001
{
    public partial class JSON1 : System.Web.UI.Page
    {
     protected void SearchData(object sender, EventArgs e)
        {
            Page_Load(null, null);
        }
         private string GetDataSource()
         {
             var responseFromDb = "0";
             if (Text1.Text != "")
             {
                 responseFromDb = GetdataFromDb(Text1.Text);
             }
            else
            {
                responseFromDb = "Click 'GO' ";
            }
             return responseFromDb;

         }

         private string GetdataFromDb(string text)
         {
           // string strQuery = @"SELECT SubsidiaryCyber.cyberResilience FROM SubsidiaryCyber WHERE SubsidiaryCyber.CompanyName like '%'+@text+'%'";
            string access_link = (@"Server=TCP:192.168.1.146,1433; Database=CRM_Subsidiaries; User Id=sa; Password = sa#1234;");
            SqlConnection conn = new SqlConnection(access_link);
            var con = ConfigurationManager.ConnectionStrings["conString"].ToString();

            string matchingPerson = "";
            using (SqlConnection myConnection = new SqlConnection(con))
            {
                string oString = "SELECT SubsidiaryCyber.cyberResilience FROM SubsidiaryCyber WHERE SubsidiaryCyber.CompanyName like '%'+@text+'%'";
                SqlCommand oCmd = new SqlCommand(oString, conn);
                oCmd.Parameters.AddWithValue("@text", text);
                conn.Open();
                using (SqlDataReader oReader = oCmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                       matchingPerson = oReader["cyberResilience"].ToString();
                    }

                    myConnection.Close();
                }
            }
            return matchingPerson;
        }
        
       

        protected void Text2_TextChanged(object sender, EventArgs e)
        {

        }
        private string GetData()
        {
            var responseFromDb = GetDataSource();
            var json2Path = @"C:\Users\fcyfcy\Desktop\CRM_Subsidiaries\Charts001\Charts001\Data\json2.json";
            JObject o1 = JObject.Parse(File.ReadAllText(json2Path));
            o1["dials"]["dial"][0]["value"] = string.Format("{0}", responseFromDb);

            // write JSON directly to a file
            using (StreamWriter file = File.CreateText(json2Path))
            using (JsonTextWriter writer = new JsonTextWriter(file))
            {
                o1.WriteTo(writer);
            }

            return json2Path;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            // var a = CRM_DB.GetDBdata();
            GetData();
            Chart correlationGraph = new Chart("bar3d", "myChart", "500", "250", "jsonurl", "../Data/json.json"); 
            // Render the chart
            Literal1.Text = correlationGraph.Render();

            Chart companySample = new Chart("angulargauge", "myChart5", "500", "300", "jsonurl", "../Data/json2.json"); 
            Literal2.Text = companySample.Render();

            Text2.Text = GetDataSource();

            Chart databaseSeach = new Chart("line", "myChart4", "500", "250", "jsonurl", "../Data/don.json"); 
            // Render the chart
            Literal3.Text = databaseSeach.Render();



        }
    }
}                
        

     